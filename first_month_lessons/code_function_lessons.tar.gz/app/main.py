import utils

a = utils.calc("asdfas",1,21,12,12)
print(a)
